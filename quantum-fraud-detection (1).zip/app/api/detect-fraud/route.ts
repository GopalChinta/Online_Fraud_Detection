import { type NextRequest, NextResponse } from "next/server"
import { detectFraud } from "@/lib/fraud-detection"
import type { TransactionData } from "@/lib/types"

export async function POST(request: NextRequest) {
  try {
    const transactionData: TransactionData = await request.json()

    // Validate the transaction data
    if (!transactionData.amount || !transactionData.customerId || !transactionData.merchantId) {
      return NextResponse.json({ error: "Missing required transaction data" }, { status: 400 })
    }

    // Process the transaction with our fraud detection system
    const result = await detectFraud(transactionData)

    // Return the detection result
    return NextResponse.json(result)
  } catch (error) {
    console.error("Error in fraud detection API:", error)
    return NextResponse.json({ error: "Failed to process transaction" }, { status: 500 })
  }
}

